<#
NetScaler upgrade jobs through NetScaler Console.

Check     looks at each selected HA pair (build, HA roles, /var and /flash) and the
          jobs already in Console. Creates nothing.
Create    uploads the image if needed and creates a SCHEDULED upgrade job in Console.
          It never upgrades right away; the job shows under Infrastructure > Upgrade Jobs.
Verify    after the upgrade window: job status, new build on both nodes, HA roles and sync.

Runs on the PowerShell built into Windows (5.1) and on PowerShell 7.
#>
[CmdletBinding()]
param([string]$SettingsPath)

$ErrorActionPreference = 'Stop'

if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    Write-Host "PowerShell on this PC runs in restricted mode ($($ExecutionContext.SessionState.LanguageMode))."
    Write-Host "The tool needs normal mode. Please ask IT to allow this script."
    exit 1
}

$Root = $PSScriptRoot
if (-not $SettingsPath) { $SettingsPath = Join-Path $Root 'NetScalerUpgrade.settings.json' }
$ReportDir = Join-Path $Root 'reports'

if (-not ('NsTls' -as [type])) {
    Add-Type -TypeDefinition @"
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
public static class NsTls {
    static bool Accept(object s, X509Certificate c, X509Chain ch, SslPolicyErrors e) { return true; }
    public static readonly RemoteCertificateValidationCallback Callback = Accept;
}
"@
}
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$script:Pump = { }

# ---------------------------------------------------------------- settings

function Get-DefaultSettings {
    [ordered]@{
        console          = ''
        username         = 'nsroot'
        protocol         = 'auto'
        image_name       = ''
        image_file       = ''
        job_name         = ''
        schedule         = ''
        pairs            = @()
        do_backup        = $true
        do_cleanup       = $true
        save_config      = $false
        keep_ha_roles    = $false
        minimum_var_mb   = 7168
        minimum_flash_mb = 200
    }
}

function Read-Settings {
    $s = Get-DefaultSettings
    if (Test-Path $SettingsPath) {
        $saved = Get-Content $SettingsPath -Raw | ConvertFrom-Json
        foreach ($p in $saved.PSObject.Properties) { $s[$p.Name] = $p.Value }
    }
    $s.pairs = @($s.pairs | Where-Object { $_ } | ForEach-Object { "$_".Trim() })
    $s
}

function Save-Settings($s) {
    # the password is never written to disk
    $s | ConvertTo-Json -Depth 4 | Set-Content -Path $SettingsPath -Encoding UTF8
}

# ---------------------------------------------------------------- Console connection

function Invoke-Console($S, [string]$Method, [string]$Path, $Body, $Headers, [string]$UploadFile, $Log) {
    try {
        $req = [System.Net.WebRequest]::Create($S.Root + $Path)
        $req.Method = $Method
        $req.Proxy = $null
        $req.Accept = 'application/json'
        $req.Timeout = 120000
        $req.ReadWriteTimeout = 120000
        if ($S.Protocol -eq 'https') { $req.ServerCertificateValidationCallback = [NsTls]::Callback }
        if ($S.Token) {
            # Console has used both names over the years; sending both is harmless
            $req.Headers.Add('Cookie', "SESSID=$($S.Token); NITRO_AUTH_TOKEN=$($S.Token)")
            $req.Headers.Add('SESSID', $S.Token)
        }
        if ($Headers) { foreach ($k in $Headers.Keys) { $req.Headers.Add($k, "$($Headers[$k])") } }

        if ($UploadFile) {
            $boundary = '----NsImage' + [guid]::NewGuid().ToString('N')
            $name = [IO.Path]::GetFileName($UploadFile)
            $head = [Text.Encoding]::UTF8.GetBytes("--$boundary`r`nContent-Disposition: form-data; name=`"ns_images`"; filename=`"$name`"`r`nContent-Type: application/octet-stream`r`n`r`n")
            $tail = [Text.Encoding]::UTF8.GetBytes("`r`n--$boundary--`r`n")
            $size = (Get-Item -LiteralPath $UploadFile).Length
            $req.ContentType = "multipart/form-data; boundary=$boundary"
            $req.ContentLength = $head.Length + $size + $tail.Length
            $req.AllowWriteStreamBuffering = $false
            $req.Timeout = 7200000
            $req.ReadWriteTimeout = 7200000
            $out = $req.GetRequestStream()
            $out.Write($head, 0, $head.Length)
            $in = [IO.File]::OpenRead($UploadFile)
            try {
                $buf = New-Object byte[] (4MB)
                $sent = 0; $nextReport = 10
                while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
                    $out.Write($buf, 0, $n)
                    $sent += $n
                    $pct = [math]::Floor($sent * 100 / [math]::Max(1, $size))
                    if ($Log -and $pct -ge $nextReport) { & $Log "    uploaded $pct%"; $nextReport += 10 }
                    & $script:Pump
                }
            }
            finally { $in.Close() }
            $out.Write($tail, 0, $tail.Length)
            $out.Close()
        }
        elseif ($null -ne $Body) {
            # a string is sent as it is (Console login takes the form object={...})
            $text = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 8 -Compress }
            $bytes = [Text.Encoding]::UTF8.GetBytes($text)
            $req.ContentType = 'application/json'
            $req.ContentLength = $bytes.Length
            $stream = $req.GetRequestStream()
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Close()
        }
        $resp = $req.GetResponse()
    }
    catch {
        $e = $_.Exception
        while ($e -and -not ($e -is [System.Net.WebException]) -and $e.InnerException) { $e = $e.InnerException }
        if ($e -is [System.Net.WebException] -and $e.Response) {
            $raw = (New-Object IO.StreamReader($e.Response.GetResponseStream())).ReadToEnd()
            $code = [int]$e.Response.StatusCode
            $msg = $raw
            try {
                $j = $raw | ConvertFrom-Json
                if ($j.message) { $msg = $j.message }
                if ($j.errorcode) { $msg = "[$($j.errorcode)] $msg" }
            } catch { }
            throw "$Method $Path failed ($code): $msg"
        }
        throw "cannot reach $($S.Address): $($e.Message)"
    }
    $script:LastSetCookie = "$($resp.Headers['Set-Cookie'])"
    $reader = New-Object IO.StreamReader($resp.GetResponseStream())
    $raw = $reader.ReadToEnd()
    $reader.Close()
    $resp.Close()
    if (-not $raw.Trim()) { return [pscustomobject]@{} }
    $data = $raw | ConvertFrom-Json
    if ($data.errorcode -and "$($data.errorcode)" -ne '0') { throw "$Method $Path : [$($data.errorcode)] $($data.message)" }
    $data
}

function Connect-Console($Address, $Protocol, $User, $Pass) {
    $protocols = if ($Protocol -eq 'auto') { @('https', 'http') } else { @($Protocol) }
    $login = @{ login = @{ username = $User; password = $Pass } } | ConvertTo-Json -Compress
    # Citrix's own SDK and other working Console clients send object={...}; plain JSON is the fallback
    $bodies = @("object=$login", $login)
    $lastErr = $null
    foreach ($p in $protocols) {
        $S = @{ Address = $Address; Protocol = $p; Root = "${p}://$Address/nitro"; Token = $null }
        $unreachable = $false
        foreach ($b in $bodies) {
            try {
                $script:LastSetCookie = ''
                $r = Invoke-Console $S POST '/v1/config/login' $b
                $id = $null
                if ($r.login) { $id = @($r.login)[0].sessionid }
                if (-not $id) { $id = $r.sessionid }
                if (-not $id -and $script:LastSetCookie -match '(SESSID|NITRO_AUTH_TOKEN)=([^;,\s]+)') { $id = $Matches[2] }
                if (-not $id) { throw 'login returned no session id' }
                $S.Token = $id
                return $S
            }
            catch {
                $lastErr = "$_"
                if ($lastErr -match '^cannot reach') { $unreachable = $true; break }
                # A rejected password usually means it is wrong; retrying could lock the account.
                # Only when the password has characters a form body can garble (+ & % =) is the
                # plain JSON format tried once more.
                $rejected = $lastErr -match '\[354\]|nvalid username|nvalid user|locked'
                if ($rejected -and ($b -ne $bodies[0] -or $Pass -notmatch '[+&%=]')) { throw "login to Console failed: $lastErr" }
            }
        }
        if (-not $unreachable) { break }
    }
    throw "login to Console failed: $lastErr"
}

function Disconnect-Console($S) {
    if (-not $S -or -not $S.Token) { return }
    try { Invoke-Console $S DELETE '/v1/config/login' | Out-Null } catch { }
    $S.Token = $null
}

# ---------------------------------------------------------------- inventory

function Get-BuildFromVersion($Text) {
    if ("$Text" -match 'NS(\d+\.\d+)[:\s,]*Build\s*(\d+\.\d+)') { return "$($Matches[1])-$($Matches[2])" }
    $null
}

function Get-BuildFromImage($Name) {
    if ("$Name" -match '(\d{2}\.\d)-(\d{1,3}\.\d{1,3})') { return "$($Matches[1])-$($Matches[2])" }
    $null
}

function ConvertTo-BuildVersion($Build) { [version]($Build -replace '-', '.') }

function Get-IpSortKey($Ip) {
    # 10.150.10.9 sorts before 10.150.10.10
    (("$Ip" -split '[.:]') | ForEach-Object { "$_".PadLeft(5, '0') }) -join '.'
}

function Get-Pairs($S) {
    $r = Invoke-Console $S GET '/v2/config/ns'
    $nodes = @($r.ns | Where-Object { $_ -and $_.ip_address })
    $byIp = @{}
    foreach ($n in $nodes) { $byIp["$($n.ip_address)"] = $n }
    $pairs = @(); $seen = @{}
    foreach ($n in $nodes) {
        $ip = "$($n.ip_address)"
        if ($seen[$ip]) { continue }
        $peer = "$($n.ha_ip_address)"
        $members = @($n)
        if ($peer -and $byIp[$peer] -and -not $seen[$peer]) { $members += $byIp[$peer] }
        # keep the order Console shows in its display name (e.g. 10.150.10.101-10.150.10.102)
        $members = @($members | Sort-Object { Get-IpSortKey $_.ip_address })
        foreach ($m in $members) { $seen["$($m.ip_address)"] = $true }
        $key = ($members | ForEach-Object { "$($_.ip_address)" }) -join '-'
        $hostName = @($members | ForEach-Object { "$($_.hostname)" } | Where-Object { $_ })[0]
        if (-not $hostName) { $hostName = "$($n.display_name)" }
        $pairs += [pscustomobject]@{
            Key   = $key
            Name  = $hostName
            Nodes = $members
            Build = Get-BuildFromVersion $members[0].version
            State = (($members | ForEach-Object { "$($_.instance_state)" }) -join ' / ')
        }
    }
    $pairs | Sort-Object Key
}

function Get-NodeStatus($S, $Node) {
    # live figures straight from the appliance through Console; falls back to Console's own inventory
    $ip = "$($Node.ip_address)"
    $h = @{ '_MPS_API_PROXY_MANAGED_INSTANCE_IP' = $ip; '_MPS_API_PROXY_TIMEOUT' = '60' }
    $st = [ordered]@{
        Ip = $ip; Build = $null; VersionText = ''; Role = ''; HaState = ''; Sync = ''; HaMode = ''
        VarFree = $null; FlashFree = $null; Source = ''; Up = $true; Platform = ''
    }
    try {
        $v = Invoke-Console $S GET '/v1/config/nsversion' $null $h
        $st.VersionText = "$(@($v.nsversion)[0].version)"
        $st.Build = Get-BuildFromVersion $st.VersionText
        $sys = (Invoke-Console $S GET '/v1/stat/system' $null $h).system
        foreach ($f in 'disk1avail', 'disk1_free') { if ($null -ne $sys.$f -and "$($sys.$f)" -ne '') { $st.VarFree = [double]$sys.$f; break } }
        foreach ($f in 'disk0avail', 'disk0_free') { if ($null -ne $sys.$f -and "$($sys.$f)" -ne '') { $st.FlashFree = [double]$sys.$f; break } }
        try {
            $ha = @((Invoke-Console $S GET '/v1/config/hanode' $null $h).hanode | Where-Object { $_ })
            $local = $ha | Where-Object { "$($_.id)" -eq '0' } | Select-Object -First 1
            if ($local) {
                # state = current role (Primary/Secondary); hastatus = forced mode (ENABLED, STAYPRIMARY, ...)
                $st.Role = "$($local.state)"
                $st.HaMode = "$($local.hastatus)"
                $reason = "$($local.hasyncfailurereason)"
                if ($reason.Trim() -and $reason -notmatch '^\s*(none|-+|n/?a|success|ok)\.?\s*$') { $st.Sync = "failed: $reason" }
            }
            if (-not $ha.Count) { $st.Role = 'Standalone' }
        } catch { }
        try {
            $hs = @((Invoke-Console $S GET '/v1/stat/hanode' $null $h).hanode)[0]
            if ($hs.hacurstate) { $st.HaState = "$($hs.hacurstate)" }
            if (-not $st.Role -and $hs.hacurmasterstate) { $st.Role = "$($hs.hacurmasterstate)" }
        } catch { }
        try {
            # Linux-based VPX keeps _lx_ install files; FreeBSD-based keeps _nc_ ones
            $files = @((Invoke-Console $S GET '/v1/config/systemfile?args=filelocation:%2Fvar%2Fnsinstall' $null $h).systemfile |
                ForEach-Object { "$($_.filename)" })
            if ($files -match '_lx_') { $st.Platform = 'lx' }
            elseif ($files -match '_nc_') { $st.Platform = 'nc' }
            else { $st.Platform = '' }
        } catch { }
        $st.Source = 'live'
    }
    catch {
        $st.Source = "Console inventory (live read failed: $_)"
    }
    if (-not $st.Build) { $st.VersionText = "$($Node.version)"; $st.Build = Get-BuildFromVersion $Node.version }
    if (-not $st.Role) { $st.Role = "$($Node.ha_master_state)" }
    if (-not $st.Sync) { $st.Sync = "$($Node.ha_sync)" }
    if ($null -eq $st.VarFree -and "$($Node.disk1_free)" -ne '') { $st.VarFree = [double]$Node.disk1_free }
    if ($null -eq $st.FlashFree -and "$($Node.disk0_free)" -ne '') { $st.FlashFree = [double]$Node.disk0_free }
    if ("$($Node.instance_state)" -and "$($Node.instance_state)" -notmatch '^up$') { $st.Up = $false }
    [pscustomobject]$st
}

function Get-Images($S) {
    $r = Invoke-Console $S GET '/v2/config/ns_image'
    @($r.ns_image | Where-Object { $_ -and $_.file_name -and -not $_.is_dir } |
        ForEach-Object { [pscustomobject]@{ Name = "$($_.file_name)"; Size = [double]$_.file_size } } |
        Sort-Object Name)
}

function Get-Jobs($S) {
    $r = Invoke-Console $S GET '/v2/config/maintenance_job'
    @($r.maintenance_job | Where-Object { $_ })
}

function Get-UpgradeRecords($S) {
    try { @((Invoke-Console $S GET '/v2/config/ns_upgrade').ns_upgrade | Where-Object { $_ }) } catch { @() }
}

function Get-JobFormat($Records, $Jobs, $Pairs) {
    # Citrix does not document how the GUI fills these two fields, so copy what the
    # jobs already in Console look like; defaults are used when there are none
    $fmt = @{ IpMode = 'both'; EpochUnit = 'seconds'; From = 'defaults (no existing job to copy from)' }
    $epochs = @()
    foreach ($x in @($Records) + @($Jobs)) { if ("$($x.scheduleTimesEpoch)" -match '^\d+') { $epochs += "$($x.scheduleTimesEpoch)" } }
    if ($epochs.Count) {
        if ($epochs[0].Split(',')[0].Trim().Length -ge 13) { $fmt.EpochUnit = 'milliseconds' }
        $fmt.From = 'existing jobs in Console'
    }
    foreach ($rec in $Records) {
        $ips = @($rec.ns_ip_address_arr | Where-Object { $_ } | ForEach-Object { "$_" })
        foreach ($p in $Pairs) {
            if ($p.Nodes.Count -lt 2) { continue }
            $inJob = @($p.Nodes | Where-Object { $ips -contains "$($_.ip_address)" })
            if ($inJob.Count -eq 1) { $fmt.IpMode = 'one'; $fmt.From = "existing job '$($rec.name)'" }
            elseif ($inJob.Count -eq 2) { $fmt.IpMode = 'both'; $fmt.From = "existing job '$($rec.name)'" }
        }
    }
    $fmt
}

# ---------------------------------------------------------------- checks

function Format-MB($v) {
    if ($null -eq $v -or "$v" -eq '') { return '?' }
    [string]::Format([Globalization.CultureInfo]::InvariantCulture, '{0:N0} MB', [double]$v)
}

function New-ResultRow($Pair, $st, $notes) {
    $var = ''; $flash = ''
    if ($null -ne $st.VarFree) { $var = [math]::Round($st.VarFree) }
    if ($null -ne $st.FlashFree) { $flash = [math]::Round($st.FlashFree) }
    [pscustomobject][ordered]@{
        Pair = $Pair.Key; Node = $st.Ip; Role = $st.Role; Build = $st.Build
        VarFreeMB = $var; FlashFreeMB = $flash; Result = ''; Notes = (@($notes) -join '; ')
    }
}

function Test-Pair($S, $Pair, $Target, $Settings, $Log, $Image) {
    & $Log ''
    & $Log "=== $($Pair.Key)  $($Pair.Name) ==="
    $rows = @(); $problems = @(); $already = 0
    $roles = @()
    foreach ($n in $Pair.Nodes) {
        $st = Get-NodeStatus $S $n
        $roles += $st.Role
        $notes = @()
        if (-not $st.Up) { $notes += "node is $($n.instance_state) in Console" }
        if ($st.Build -and $Target -and (ConvertTo-BuildVersion $st.Build) -ge (ConvertTo-BuildVersion $Target)) {
            $already++; $notes += "already on $($st.Build)"
        }
        if ($null -eq $st.VarFree) { $notes += '/var free space unknown' }
        elseif ($st.VarFree -lt $Settings.minimum_var_mb) { $notes += "/var below $(Format-MB $Settings.minimum_var_mb), run the cleanup tool first" }
        if ($null -ne $st.FlashFree -and $st.FlashFree -lt $Settings.minimum_flash_mb) { $notes += "/flash below $(Format-MB $Settings.minimum_flash_mb)" }
        if ($st.Sync -match 'fail') { $notes += "HA sync: $($st.Sync)" }
        if ($st.HaMode -match 'STAY|DISABLED') { $notes += "HA status is $($st.HaMode); Console will not upgrade it" }
        $imageType = if ($Image -match '_lx_') { 'lx' } elseif ($Image -match '_nc_') { 'nc' } else { '' }
        if (-not $st.Platform -and $imageType) {
            & $Log "    (could not tell if $($st.Ip) is Linux-based or FreeBSD-based; make sure the image type matches)"
        }
        if ($st.Platform -and $imageType -and $st.Platform -ne $imageType) {
            $notes += "appliance runs the $($st.Platform) (Linux = lx, FreeBSD = nc) build but the image is $imageType; pick the matching $($st.Platform) image"
        }

        & $Log "  $($st.Ip)  $($st.Role)  build $($st.Build)  /var free $(Format-MB $st.VarFree)  /flash free $(Format-MB $st.FlashFree)"
        if ($st.Source -ne 'live') { & $Log "    figures from $($st.Source)" }
        foreach ($x in $notes) { & $Log "    ! $x" }
        $problems += $notes
        $rows += New-ResultRow $Pair $st $notes
    }
    if ($Pair.Nodes.Count -eq 2) {
        $r = ($roles | Sort-Object) -join '/'
        if ($r -notmatch '^Primary/Secondary$') { $problems += "HA roles are $r"; & $Log "    ! HA roles are $r (expected one Primary and one Secondary)" }
    }
    $result = if ($already -eq $Pair.Nodes.Count) { 'ALREADY DONE' } elseif ($problems.Count) { 'NOT READY' } else { 'READY' }
    & $Log "  -> $result"
    foreach ($row in $rows) { $row.Result = $result }
    @{ Result = $result; Rows = $rows }
}

function Test-Upgraded($S, $Pair, $Target, $Job, $Log) {
    & $Log ''
    & $Log "=== $($Pair.Key)  $($Pair.Name) ==="
    $rows = @(); $bad = @(); $roles = @()
    foreach ($n in $Pair.Nodes) {
        $st = Get-NodeStatus $S $n
        $roles += $st.Role
        $notes = @()
        if (-not $st.Up) { $notes += "node is $($n.instance_state) in Console" }
        if ($Target -and $st.Build -ne $Target) { $notes += "on $($st.Build), expected $Target" }
        if ($st.HaState -and $st.HaState -notmatch '^up$') { $notes += "HA state $($st.HaState)" }
        if ($st.Sync -match 'fail') { $notes += "HA sync: $($st.Sync)" }
        & $Log "  $($st.Ip)  $($st.Role)  build $($st.Build)  HA $($st.HaState) $($st.Sync)"
        if ($st.Source -ne 'live') { & $Log "    figures from $($st.Source)" }
        foreach ($x in $notes) { & $Log "    ! $x" }
        $bad += $notes
        $rows += New-ResultRow $Pair $st $notes
    }
    if ($Pair.Nodes.Count -eq 2) {
        $r = ($roles | Sort-Object) -join '/'
        if ($r -notmatch '^Primary/Secondary$') { $bad += "HA roles are $r"; & $Log "    ! HA roles are $r" }
    }
    $jobStatus = if ($Job) { "$($Job.status)" } else { '' }
    $result = 'FAIL'
    if (-not $bad.Count) { $result = 'PASS' }
    elseif ($jobStatus -match 'Scheduled|Progress|Started') { $result = 'WAITING' }
    & $Log "  -> $result"
    foreach ($row in $rows) { $row.Result = $result }
    @{ Result = $result; Rows = $rows }
}

# ---------------------------------------------------------------- runs

function Start-Report($Kind, $Log) {
    New-Item -ItemType Directory -Force -Path $ReportDir | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $logPath = Join-Path $ReportDir "upgrade-$Kind-$stamp.log"
    $fileLog = { param($m) & $Log $m; Add-Content -Path $logPath -Value $m -Encoding UTF8 -ErrorAction Stop }.GetNewClosure()
    @{ Stamp = $stamp; Log = $fileLog; Csv = (Join-Path $ReportDir "upgrade-$Kind-$stamp.csv") }
}

function Select-Pairs($AllPairs, $Settings) {
    @($AllPairs | Where-Object { $Settings.pairs -contains $_.Key })
}

function Get-TargetBuild($Settings) {
    $name = $Settings.image_name
    if (-not $name -and $Settings.image_file) { $name = [IO.Path]::GetFileName($Settings.image_file) }
    @($name, (Get-BuildFromImage $name))
}

function Invoke-Check($Settings, $Pass, $Log, $OnRow) {
    $rep = Start-Report 'check' $Log
    $L = $rep.Log
    & $L "CHECK: nothing is uploaded or created  ($($rep.Stamp))"
    $S = Connect-Console $Settings.console $Settings.protocol $Settings.username $Pass
    $all = @()
    try {
        & $L "Connected to Console $($Settings.console) over $($S.Protocol)"
        $pairs = @(Get-Pairs $S)
        $selected = Select-Pairs $pairs $Settings
        $image, $target = Get-TargetBuild $Settings
        $images = @(Get-Images $S)
        & $L "Upgrade image: $image  (build $target)"
        if ($images.Name -contains $image) { & $L '  already on Console, no upload needed' }
        elseif ($Settings.image_file) { & $L "  not on Console yet, will be uploaded from $($Settings.image_file)" }
        else { & $L '  ! not found on Console and no file chosen to upload' }

        $jobs = @(Get-Jobs $S)
        $records = @(Get-UpgradeRecords $S)
        & $L ''
        & $L "Upgrade jobs in Console: $($jobs.Count)"
        foreach ($j in $jobs) { & $L "  $($j.name)  [$($j.status)]  $(Format-When $j.scheduleTimesEpoch)" }
        $fmt = Get-JobFormat $records $jobs $pairs
        & $L "Job format: IPs per HA pair = $($fmt.IpMode), schedule time in $($fmt.EpochUnit)  (from $($fmt.From))"

        # kept so we can confirm the job format against what Console really stores
        $raw = Join-Path $ReportDir "console-jobs-$($rep.Stamp).json"
        @{ maintenance_job = $jobs; ns_upgrade = $records } | ConvertTo-Json -Depth 8 | Set-Content -Path $raw -Encoding UTF8
        & $L "Console job details saved: $raw"

        foreach ($p in $selected) {
            $res = Test-Pair $S $p $target $Settings $L $image
            foreach ($row in $res.Rows) { $all += $row; if ($OnRow) { & $OnRow $row } }
        }
        if (-not $selected.Count) { & $L ''; & $L 'No HA pairs ticked.' }
    }
    finally { Disconnect-Console $S }
    $all | Export-Csv -Path $rep.Csv -NoTypeInformation -Encoding UTF8
    & $L ''
    & $L "Report saved: $($rep.Csv)"
    $rep.Csv
}

function Format-When($epoch) {
    $e = "$epoch".Split(',')[0].Trim()
    if ($e -notmatch '^\d+$') { return '' }
    $n = [double]$e
    if ($e.Length -ge 13) { $n = $n / 1000 }
    $local = [DateTimeOffset]::FromUnixTimeSeconds([long]$n).LocalDateTime
    $local.ToString('ddd dd MMM yyyy HH:mm') + ' (this PC time)'
}

function Invoke-CreateJob($Settings, $Pass, $When, $Log, $OnRow, $Confirm) {
    $rep = Start-Report 'create' $Log
    $L = $rep.Log
    & $L "CREATE JOB  ($($rep.Stamp))"
    $guardError = $null
    $S = Connect-Console $Settings.console $Settings.protocol $Settings.username $Pass
    $all = @()
    try {
        & $L "Connected to Console $($Settings.console) over $($S.Protocol)"
        $pairs = @(Get-Pairs $S)
        $selected = Select-Pairs $pairs $Settings
        $image, $target = Get-TargetBuild $Settings
        $jobs = @(Get-Jobs $S)
        if ($jobs | Where-Object { "$($_.name)" -eq $Settings.job_name }) {
            throw "a job named '$($Settings.job_name)' already exists in Console; pick another name"
        }

        # checks first; only pairs that pass go into the job
        $ready = @()
        foreach ($p in $selected) {
            $res = Test-Pair $S $p $target $Settings $L $image
            foreach ($row in $res.Rows) { $all += $row; if ($OnRow) { & $OnRow $row } }
            if ($res.Result -eq 'READY') { $ready += $p }
        }
        if (-not $ready.Count) { throw 'no HA pair is READY, nothing to create' }

        $fmt = Get-JobFormat (Get-UpgradeRecords $S) $jobs $pairs
        $ips = @()
        foreach ($p in $ready) {
            if ($fmt.IpMode -eq 'one') {
                $primary = @($p.Nodes | Where-Object { "$($_.ha_master_state)" -match 'primary' })[0]
                if (-not $primary) { $primary = $p.Nodes[0] }
                $ips += "$($primary.ip_address)"
            }
            else { $ips += @($p.Nodes | ForEach-Object { "$($_.ip_address)" }) }
        }
        $seconds = ([DateTimeOffset]$When).ToUnixTimeSeconds()
        $epoch = if ($fmt.EpochUnit -eq 'milliseconds') { "$($seconds * 1000)" } else { "$seconds" }

        $summary = "Job: $($Settings.job_name)`r`nImage: $image`r`nWhen: $($When.ToString('ddd dd MMM yyyy HH:mm')) (this PC time)`r`n" +
            "HA pairs:`r`n  " + (($ready | ForEach-Object { "$($_.Key)  $($_.Name)" }) -join "`r`n  ")
        & $L ''
        & $L $summary
        if ($Confirm -and -not (& $Confirm $summary)) { & $L 'Cancelled, nothing created.'; return $null }

        $images = @(Get-Images $S)
        if ($images.Name -notcontains $image) {
            if (-not $Settings.image_file -or -not (Test-Path -LiteralPath $Settings.image_file)) {
                throw "image $image is not on Console and the file to upload was not found"
            }
            & $L ''
            & $L "Uploading $image to Console..."
            Invoke-Console $S POST '/v2/upload/ns_image' $null $null $Settings.image_file $L | Out-Null
            $images = @(Get-Images $S)
            if ($images.Name -notcontains $image) {
                throw 'upload finished but Console does not list the image; upload it once in Console (Upgrade Jobs > Select Image) and pick it from the list'
            }
            & $L '  upload done'
        }

        $body = @{ ns_upgrade = [ordered]@{
                name                     = $Settings.job_name
                image_name               = $image
                ns_ip_address_arr        = $ips
                scheduleTimesEpoch       = $epoch
                do_backup                = [bool]$Settings.do_backup
                do_cleanup               = [bool]$Settings.do_cleanup
                saveconfig_enabled       = [bool]$Settings.save_config
            }
        }
        # only sent when ticked, so an older Console that lacks the field is not affected
        if ($Settings.keep_ha_roles) { $body.ns_upgrade['second_failover_enabled'] = $true }
        & $L ''
        & $L "Sending job to Console (IPs: $($ips -join ', '); time $epoch)"
        Invoke-Console $S POST '/v2/config/ns_upgrade?action=upgrade' $body | Out-Null
        $guardError = Confirm-NewJob $S $Settings.job_name $seconds $L
    }
    finally { Disconnect-Console $S }
    $all | Export-Csv -Path $rep.Csv -NoTypeInformation -Encoding UTF8
    & $L "Report saved: $($rep.Csv)"
    if ($guardError) { throw $guardError }
    $rep.Csv
}

function Get-EpochSeconds($Value) {
    $e = "$Value".Split(',')[0].Trim()
    if ($e -notmatch '^\d+$') { return $null }
    $n = [double]$e
    if ($e.Length -ge 13) { $n = $n / 1000 }
    [long]$n
}

function Confirm-NewJob($S, $Name, [long]$WantSeconds, $Log) {
    # Safety guard. Read the new job back from Console and remove it at once if it is
    # not waiting for the time that was picked (wrong time, or already running).
    # Returns an error message when the guard had to act, otherwise nothing.
    $job = $null; $why = $null; $readError = $null
    for ($round = 1; $round -le 3; $round++) {
        # give Console a moment; a job that starts by mistake shows it within seconds
        for ($t = 0; $t -lt 100; $t++) { Start-Sleep -Milliseconds 100; & $script:Pump }
        try { $job = Get-Jobs $S | Where-Object { "$($_.name)" -eq $Name } | Select-Object -First 1 }
        catch { $readError = "$_"; break }
        if (-not $job) { continue }
        $status = "$($job.status)"
        $running = ($status -match 'progress|running|complete|success|fail|error') -or
            ($status -match 'start' -and $status -notmatch 'not')
        if ($running) {
            $why = "the job status is '$status' instead of Scheduled"; break
        }
        $got = Get-EpochSeconds $job.scheduleTimesEpoch
        if ($null -eq $got) {
            $rec = $null
            try { $rec = Get-UpgradeRecords $S | Where-Object { "$($_.name)" -eq $Name } | Select-Object -First 1 } catch { }
            if ($rec) { $got = Get-EpochSeconds $rec.scheduleTimesEpoch }
        }
        if ($null -ne $got -and [math]::Abs($got - $WantSeconds) -gt 120) {
            $why = "Console stored the time as $(Format-When $got) instead of $(Format-When $WantSeconds)"; break
        }
    }

    if ($readError) {
        & $Log ''
        & $Log "! The job was sent, but reading it back failed: $readError"
        & $Log '! Open Console > Infrastructure > Upgrade Jobs NOW and check its time, or delete it.'
        return 'the new job could not be read back from Console; check Infrastructure > Upgrade Jobs now'
    }
    if (-not $job) {
        & $Log ''
        & $Log '! Console accepted the job but it does not appear in the job list.'
        & $Log '! Open Console > Infrastructure > Upgrade Jobs NOW and check its time, or delete it.'
        return 'the new job could not be read back from Console; check Infrastructure > Upgrade Jobs now'
    }
    if (-not $why) {
        & $Log ''
        & $Log "Job created: $($job.name)  [$($job.status)]  $(Format-When $job.scheduleTimesEpoch)"
        & $Log 'Safety check passed: the job is waiting for the time you picked.'
        & $Log 'It runs at that time. To cancel, stop or delete it in Console under Infrastructure > Upgrade Jobs.'
        return $null
    }

    & $Log ''
    & $Log "! SAFETY STOP: $why."
    try {
        Invoke-Console $S DELETE "/v2/config/maintenance_job/$([Uri]::EscapeDataString("$($job.id)"))" | Out-Null
        & $Log "  The job '$Name' was deleted from Console."
        & $Log '  If it had already started, check the appliances in Console before doing anything else.'
        & $Log '  Please send the reports folder so the job format can be corrected.'
        return "safety stop: $why. The job was deleted."
    }
    catch {
        & $Log "! Could not delete the job: $_"
        & $Log "! Open Console > Infrastructure > Upgrade Jobs NOW and stop or delete '$Name'."
        return "safety stop: $why. The job could NOT be deleted, stop it in Console now."
    }
}

function Invoke-Verify($Settings, $Pass, $Log, $OnRow) {
    $rep = Start-Report 'verify' $Log
    $L = $rep.Log
    & $L "AFTER-UPGRADE CHECK  ($($rep.Stamp))"
    $S = Connect-Console $Settings.console $Settings.protocol $Settings.username $Pass
    $all = @()
    try {
        & $L "Connected to Console $($Settings.console) over $($S.Protocol)"
        $pairs = @(Get-Pairs $S)
        $selected = Select-Pairs $pairs $Settings
        $image, $target = Get-TargetBuild $Settings
        $job = Get-Jobs $S | Where-Object { "$($_.name)" -eq $Settings.job_name } | Select-Object -First 1
        if ($job) { & $L "Job $($job.name): $($job.status)  $(Format-When $job.scheduleTimesEpoch)" }
        else { & $L "Job '$($Settings.job_name)' not found in Console" }
        & $L "Expected build: $target"
        foreach ($p in $selected) {
            $res = Test-Upgraded $S $p $target $job $L
            foreach ($row in $res.Rows) { $all += $row; if ($OnRow) { & $OnRow $row } }
        }
    }
    finally { Disconnect-Console $S }
    $all | Export-Csv -Path $rep.Csv -NoTypeInformation -Encoding UTF8
    & $L ''
    & $L "Report saved: $($rep.Csv)"
    $rep.Csv
}

# ---------------------------------------------------------------- window

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:Pump = { [System.Windows.Forms.Application]::DoEvents() }

$Ink = [Drawing.Color]::FromArgb(27, 36, 48)
$Paper = [Drawing.Color]::FromArgb(244, 241, 234)
$Amber = [Drawing.Color]::FromArgb(222, 150, 48)
$Danger = [Drawing.Color]::FromArgb(178, 58, 58)
$Muted = [Drawing.Color]::FromArgb(105, 112, 122)
$PassBg = [Drawing.Color]::FromArgb(222, 240, 228)
$FailBg = [Drawing.Color]::FromArgb(250, 232, 214)
$ErrBg = [Drawing.Color]::FromArgb(246, 222, 222)
$WaitBg = [Drawing.Color]::FromArgb(232, 236, 244)
$FontBody = New-Object Drawing.Font('Segoe UI', 9.5)
$Bold = New-Object Drawing.Font('Segoe UI Semibold', 9.5)
$Small = New-Object Drawing.Font('Segoe UI', 8.5)

$form = New-Object Windows.Forms.Form
$form.Text = 'NetScaler Upgrade Jobs'
$form.ClientSize = New-Object Drawing.Size(1100, 800)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $Paper
$form.Font = $FontBody
$form.AutoScaleMode = 'None'
$form.AutoScroll = $true

$header = New-Object Windows.Forms.Panel
$header.SetBounds(0, 0, 1100, 78)
$header.BackColor = $Ink
$form.Controls.Add($header)
$accent = New-Object Windows.Forms.Panel
$accent.SetBounds(0, 78, 1100, 4)
$accent.BackColor = $Amber
$form.Controls.Add($accent)

$title = New-Object Windows.Forms.Label
$title.Text = 'NetScaler Upgrade Jobs'
$title.Font = New-Object Drawing.Font('Segoe UI Semibold', 16)
$title.ForeColor = [Drawing.Color]::White
$title.SetBounds(22, 12, 700, 34)
$header.Controls.Add($title)
$subtitle = New-Object Windows.Forms.Label
$subtitle.Text = 'Checks HA pairs, creates scheduled upgrade jobs in NetScaler Console, and verifies them afterwards.'
$subtitle.ForeColor = [Drawing.Color]::FromArgb(190, 198, 208)
$subtitle.SetBounds(24, 47, 900, 22)
$header.Controls.Add($subtitle)

function New-Label($text, $x, $y, $w = 330) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $text; $l.Font = $Bold; $l.ForeColor = $Ink
    $l.SetBounds($x, $y, $w, 20)
    $form.Controls.Add($l); $l
}
function New-Hint($text, $x, $y, $w = 330) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $text; $l.Font = $Small; $l.ForeColor = $Muted
    $l.SetBounds($x, $y, $w, 18)
    $form.Controls.Add($l); $l
}
function New-Box($x, $y, $w = 330, $h = 26) {
    $t = New-Object Windows.Forms.TextBox
    $t.SetBounds($x, $y, $w, $h); $t.BorderStyle = 'FixedSingle'
    $form.Controls.Add($t); $t
}
function New-Button($text, $x, $y, $w, $back, $fore) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text; $b.SetBounds($x, $y, $w, 36)
    $b.FlatStyle = 'Flat'; $b.Font = $Bold
    $b.BackColor = $back; $b.ForeColor = $fore
    $b.FlatAppearance.BorderColor = $fore
    $b.Cursor = [Windows.Forms.Cursors]::Hand
    $form.Controls.Add($b); $b
}
function New-Check($text, $x, $y) {
    $c = New-Object Windows.Forms.CheckBox
    $c.Text = $text; $c.SetBounds($x, $y, 330, 22)
    $form.Controls.Add($c); $c
}
function New-Grid($x, $y, $w, $h) {
    $g = New-Object Windows.Forms.DataGridView
    $g.SetBounds($x, $y, $w, $h)
    $g.BackgroundColor = [Drawing.Color]::White
    $g.BorderStyle = 'FixedSingle'
    $g.AllowUserToAddRows = $false
    $g.AllowUserToResizeRows = $false
    $g.RowHeadersVisible = $false
    $g.SelectionMode = 'FullRowSelect'
    $g.AutoSizeColumnsMode = 'Fill'
    $g.EnableHeadersVisualStyles = $false
    $g.ColumnHeadersDefaultCellStyle.BackColor = $Ink
    $g.ColumnHeadersDefaultCellStyle.ForeColor = [Drawing.Color]::White
    $g.ColumnHeadersDefaultCellStyle.Font = $Bold
    $g.ColumnHeadersHeight = 30
    $g.GridColor = [Drawing.Color]::FromArgb(230, 226, 218)
    $g.DefaultCellStyle.SelectionBackColor = [Drawing.Color]::FromArgb(236, 230, 216)
    $g.DefaultCellStyle.SelectionForeColor = $Ink
    $form.Controls.Add($g); $g
}

# ---- settings column
$x = 24
(New-Label 'SETTINGS' $x 98).ForeColor = $Amber

New-Label 'NetScaler Console' $x 124 | Out-Null
New-Hint 'Address of NetScaler Console, e.g. 10.150.10.104' $x 143 | Out-Null
$tbConsole = New-Box $x 163

New-Label 'Username' $x 197 160 | Out-Null
$tbUser = New-Box $x 218 160
New-Label 'Password' ($x + 170) 197 160 | Out-Null
$tbPass = New-Box ($x + 170) 218 160
$tbPass.UseSystemPasswordChar = $true
New-Hint 'Your NetScaler Console login. Never saved.' $x 246 | Out-Null

New-Label 'Connection' $x 268 | Out-Null
$cbProto = New-Object Windows.Forms.ComboBox
$cbProto.DropDownStyle = 'DropDownList'
$cbProto.SetBounds($x, 289, 330, 26)
[void]$cbProto.Items.AddRange(@('auto  (https, then http)', 'https only', 'http only'))
$form.Controls.Add($cbProto)

$btnLoad = New-Button 'Load from Console' $x 324 330 $Ink ([Drawing.Color]::White)

New-Label 'Upgrade image' $x 372 | Out-Null
New-Hint 'Images already on Console, or upload a new one.' $x 391 | Out-Null
$cbImage = New-Object Windows.Forms.ComboBox
$cbImage.DropDownStyle = 'DropDown'
$cbImage.SetBounds($x, 411, 236, 26)
$form.Controls.Add($cbImage)
$btnBrowse = New-Button 'Upload...' ($x + 244) 409 86 $Paper $Ink
$btnBrowse.Height = 28
$lblFile = New-Hint '' $x 439

New-Label 'Job name' $x 462 | Out-Null
$tbJob = New-Box $x 483

New-Label 'Run the upgrade at' $x 517 | Out-Null
$dtWhen = New-Object Windows.Forms.DateTimePicker
$dtWhen.Format = 'Custom'
$dtWhen.CustomFormat = 'ddd dd MMM yyyy   HH:mm'
$dtWhen.SetBounds($x, 538, 330, 26)
$form.Controls.Add($dtWhen)
New-Hint 'Time on this PC. The job is always scheduled, never run now.' $x 566 | Out-Null

$chkBackup = New-Check 'Back up the instances before the upgrade' $x 590
$chkCleanup = New-Check 'Remove the image from NetScaler after success' $x 613
$chkSave = New-Check 'Save the configuration before the upgrade' $x 636
$chkRoles = New-Check 'Keep primary and secondary roles after upgrade' $x 659

New-Label 'Minimum free /var (MB)' $x 690 160 | Out-Null
$numVar = New-Object Windows.Forms.NumericUpDown
$numVar.SetBounds($x, 711, 160, 26); $numVar.Maximum = 1000000; $numVar.ThousandsSeparator = $true
$form.Controls.Add($numVar)
New-Label 'Minimum free /flash (MB)' ($x + 170) 690 160 | Out-Null
$numFlash = New-Object Windows.Forms.NumericUpDown
$numFlash.SetBounds(($x + 170), 711, 160, 26); $numFlash.Maximum = 1000000; $numFlash.ThousandsSeparator = $true
$form.Controls.Add($numFlash)

$btnSave = New-Button 'Save settings' $x 750 330 $Paper $Ink
$btnSave.Height = 26
$btnSave.Font = $Small

$divider = New-Object Windows.Forms.Panel
$divider.SetBounds(374, 98, 1, 680)
$divider.BackColor = [Drawing.Color]::FromArgb(214, 208, 196)
$form.Controls.Add($divider)

# ---- run column
$rx = 396
(New-Label 'HA PAIRS' $rx 98).ForeColor = $Amber
New-Hint 'Tick the pairs to upgrade. Click "Load from Console" to fill this list.' ($rx + 90) 99 500 | Out-Null
$gridPairs = New-Grid $rx 122 684 150
$colTick = New-Object Windows.Forms.DataGridViewCheckBoxColumn
$colTick.HeaderText = ''; $colTick.Width = 36; $colTick.AutoSizeMode = 'None'
[void]$gridPairs.Columns.Add($colTick)
foreach ($c in 'HA pair', 'Name', 'Build', 'State') {
    $i = $gridPairs.Columns.Add($c, $c); $gridPairs.Columns[$i].ReadOnly = $true
}

$gridPairs.Add_CurrentCellDirtyStateChanged({
    if ($gridPairs.IsCurrentCellDirty) { [void]$gridPairs.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit) }
})

$btnCheck = New-Button 'Check' $rx 286 140 $Amber $Ink
$btnCheck.FlatAppearance.BorderColor = $Amber
$btnCreate = New-Button 'Create job' ($rx + 150) 286 140 $Paper $Danger
$btnVerify = New-Button 'Check after upgrade' ($rx + 300) 286 190 $Paper $Ink
$btnReports = New-Button 'Open reports' ($rx + 524) 286 160 $Paper $Ink
$lblStatus = New-Hint 'Start with Check. It reads only and creates nothing.' $rx 328 684

$grid = New-Grid $rx 352 684 180
$grid.ReadOnly = $true
foreach ($c in 'HA pair', 'Node', 'Role', 'Build', '/var free', 'Result') { [void]$grid.Columns.Add($c, $c) }

New-Label 'Details' $rx 542 | Out-Null
$tbLog = New-Object Windows.Forms.TextBox
$tbLog.SetBounds($rx, 564, 684, 214)
$tbLog.Multiline = $true; $tbLog.ScrollBars = 'Vertical'; $tbLog.ReadOnly = $true
$tbLog.Font = New-Object Drawing.Font('Consolas', 9)
$tbLog.BackColor = [Drawing.Color]::FromArgb(250, 249, 246)
$tbLog.BorderStyle = 'FixedSingle'
$form.Controls.Add($tbLog)

# ---- wiring
$script:Ticked = @()

function Show-Settings($s) {
    $tbConsole.Text = $s.console
    $tbUser.Text = $s.username
    $cbProto.SelectedIndex = switch ($s.protocol) { 'https' { 1 } 'http' { 2 } default { 0 } }
    $cbImage.Text = $s.image_name
    $lblFile.Text = if ($s.image_file) { "Upload from: $($s.image_file)" } else { '' }
    $script:ImageFile = $s.image_file
    $tbJob.Text = $s.job_name
    $when = $null
    if ($s.schedule) { try { $when = [datetime]::ParseExact($s.schedule, 'yyyy-MM-dd HH:mm', [Globalization.CultureInfo]::InvariantCulture) } catch { } }
    if (-not $when -or $when -lt (Get-Date)) { $when = (Get-Date).Date.AddDays(1).AddHours(20).AddMinutes(30) }
    $dtWhen.Value = $when
    $chkBackup.Checked = [bool]$s.do_backup
    $chkCleanup.Checked = [bool]$s.do_cleanup
    $chkSave.Checked = [bool]$s.save_config
    $chkRoles.Checked = [bool]$s.keep_ha_roles
    $numVar.Value = [decimal]$s.minimum_var_mb
    $numFlash.Value = [decimal]$s.minimum_flash_mb
    $script:Ticked = @($s.pairs)
}

function Get-TickedPairs {
    $keys = @()
    foreach ($row in $gridPairs.Rows) { if ($row.Cells[0].Value -eq $true) { $keys += "$($row.Cells[1].Value)" } }
    if ($gridPairs.Rows.Count -eq 0) { $keys = $script:Ticked }
    $keys
}

function Get-FormSettings {
    $s = Get-DefaultSettings
    $s.console = $tbConsole.Text.Trim()
    $s.username = $tbUser.Text.Trim()
    $s.protocol = @('auto', 'https', 'http')[[math]::Max(0, $cbProto.SelectedIndex)]
    $s.image_name = $cbImage.Text.Trim()
    $s.image_file = $script:ImageFile
    if ($s.image_file -and [IO.Path]::GetFileName($s.image_file) -ne $s.image_name) { $s.image_file = '' }
    $s.job_name = $tbJob.Text.Trim()
    $s.schedule = $dtWhen.Value.ToString('yyyy-MM-dd HH:mm', [Globalization.CultureInfo]::InvariantCulture)
    $s.pairs = @(Get-TickedPairs)
    $s.do_backup = $chkBackup.Checked
    $s.do_cleanup = $chkCleanup.Checked
    $s.save_config = $chkSave.Checked
    $s.keep_ha_roles = $chkRoles.Checked
    $s.minimum_var_mb = [int]$numVar.Value
    $s.minimum_flash_mb = [int]$numFlash.Value
    $s
}

function Add-ResultRow($r) {
    $i = $grid.Rows.Add($r.Pair, $r.Node, $r.Role, $r.Build, (Format-MB $r.VarFreeMB), $r.Result)
    $color = switch -Wildcard ($r.Result) {
        'READY' { $PassBg } 'PASS' { $PassBg } 'ALREADY*' { $WaitBg } 'WAITING' { $WaitBg }
        'NOT READY' { $FailBg } 'FAIL' { $FailBg } default { $ErrBg }
    }
    $grid.Rows[$i].DefaultCellStyle.BackColor = $color
    if ($r.Notes) { $grid.Rows[$i].Cells[5].ToolTipText = $r.Notes }
}

function Test-FormSettings($s, [bool]$NeedImage, [bool]$NeedJob) {
    if (-not $s.console) { return 'Enter the NetScaler Console address.' }
    if (-not $s.username) { return 'Enter the username.' }
    if (-not $tbPass.Text) { return 'Enter the password.' }
    if ($NeedImage) {
        if (-not $s.image_name) { return 'Pick the upgrade image.' }
        if (-not (Get-BuildFromImage $s.image_name)) { return "Cannot read a build number from '$($s.image_name)'." }
        if ($s.pairs.Count -eq 0) { return 'Tick at least one HA pair. Click "Load from Console" first.' }
    }
    if ($NeedJob) {
        if (-not $s.job_name) { return 'Enter a job name.' }
        if ($dtWhen.Value -lt (Get-Date).AddMinutes(15)) { return 'Pick an upgrade time at least 15 minutes from now.' }
    }
    $null
}

function Invoke-Busy($Status, $Work) {
    foreach ($b in $btnLoad, $btnCheck, $btnCreate, $btnVerify, $btnSave, $btnBrowse) { $b.Enabled = $false }
    $form.Cursor = [Windows.Forms.Cursors]::WaitCursor
    $lblStatus.Text = $Status; $lblStatus.ForeColor = $Ink
    try {
        $done = & $Work
        $lblStatus.Text = if ($done) { "Done. Report saved to $done" } else { 'Done.' }
        $lblStatus.ForeColor = $Muted
    }
    catch {
        $tbLog.AppendText("`r`nError: $_`r`n")
        $lblStatus.Text = 'Stopped with an error. See details below.'
        $lblStatus.ForeColor = $Danger
    }
    finally {
        foreach ($b in $btnLoad, $btnCheck, $btnCreate, $btnVerify, $btnSave, $btnBrowse) { $b.Enabled = $true }
        $form.Cursor = [Windows.Forms.Cursors]::Default
    }
}

$form.Add_FormClosing({
    # a run is still going; closing now would break it halfway
    if (-not $btnCheck.Enabled) { $_.Cancel = $true }
})

$uiLog = { param($m) $tbLog.AppendText("$m`r`n"); [System.Windows.Forms.Application]::DoEvents() }
$uiRow = { param($r) Add-ResultRow $r }

$btnLoad.Add_Click({
    $s = Get-FormSettings
    $problem = Test-FormSettings $s $false $false
    if ($problem) { [void][Windows.Forms.MessageBox]::Show($problem, 'Check settings', 'OK', 'Warning'); return }
    $tbLog.Clear()
    Invoke-Busy 'Reading HA pairs and images from Console...' {
        $session = Connect-Console $s.console $s.protocol $s.username $tbPass.Text
        try {
            $pairs = @(Get-Pairs $session)
            $images = @(Get-Images $session)
        }
        finally { Disconnect-Console $session }
        $keep = @(Get-TickedPairs)
        $gridPairs.Rows.Clear()
        foreach ($p in $pairs) { [void]$gridPairs.Rows.Add(($keep -contains $p.Key), $p.Key, $p.Name, $p.Build, $p.State) }
        $current = $cbImage.Text
        $cbImage.Items.Clear()
        foreach ($im in $images) { [void]$cbImage.Items.Add($im.Name) }
        $cbImage.Text = $current
        & $uiLog "Console $($s.console): $($pairs.Count) HA pairs or instances, $($images.Count) images"
        foreach ($im in $images) { & $uiLog ("  image  {0}  ({1})" -f $im.Name, (Format-MB ($im.Size / 1MB))) }
        Save-Settings (Get-FormSettings)
        $null
    }
})

$btnBrowse.Add_Click({
    $dlg = New-Object Windows.Forms.OpenFileDialog
    $dlg.Filter = 'NetScaler build (*.tgz)|*.tgz|All files (*.*)|*.*'
    $dlg.Title = 'Pick the NetScaler build to upload to Console'
    if ($dlg.ShowDialog() -eq 'OK') {
        $script:ImageFile = $dlg.FileName
        $cbImage.Text = [IO.Path]::GetFileName($dlg.FileName)
        $lblFile.Text = "Upload from: $($dlg.FileName)"
    }
})

$btnCheck.Add_Click({
    $s = Get-FormSettings
    $problem = Test-FormSettings $s $true $false
    if ($problem) { [void][Windows.Forms.MessageBox]::Show($problem, 'Check settings', 'OK', 'Warning'); return }
    Save-Settings $s
    $grid.Rows.Clear(); $tbLog.Clear()
    Invoke-Busy 'Checking. Nothing is uploaded or created.' { Invoke-Check $s $tbPass.Text $uiLog $uiRow }
})

$btnCreate.Add_Click({
    $s = Get-FormSettings
    $problem = Test-FormSettings $s $true $true
    if ($problem) { [void][Windows.Forms.MessageBox]::Show($problem, 'Check settings', 'OK', 'Warning'); return }
    Save-Settings $s
    $grid.Rows.Clear(); $tbLog.Clear()
    $confirm = {
        param($summary)
        $msg = "Create this SCHEDULED upgrade job in NetScaler Console?`r`n`r`n$summary`r`n`r`n" +
            'Only pairs that passed the check are included. You can stop or delete the job in Console before it runs.'
        ([Windows.Forms.MessageBox]::Show($msg, 'Confirm upgrade job', 'YesNo', 'Warning', 'Button2')) -eq 'Yes'
    }
    Invoke-Busy 'Creating the upgrade job...' { Invoke-CreateJob $s $tbPass.Text $dtWhen.Value $uiLog $uiRow $confirm }
})

$btnVerify.Add_Click({
    $s = Get-FormSettings
    $problem = Test-FormSettings $s $true $false
    if (-not $problem -and -not $s.job_name) { $problem = 'Enter the job name to check.' }
    if ($problem) { [void][Windows.Forms.MessageBox]::Show($problem, 'Check settings', 'OK', 'Warning'); return }
    Save-Settings $s
    $grid.Rows.Clear(); $tbLog.Clear()
    Invoke-Busy 'Checking the upgrade result...' { Invoke-Verify $s $tbPass.Text $uiLog $uiRow }
})

$btnSave.Add_Click({ Save-Settings (Get-FormSettings); $lblStatus.Text = 'Settings saved.' })
$btnReports.Add_Click({
    New-Item -ItemType Directory -Force -Path $ReportDir | Out-Null
    Start-Process explorer.exe $ReportDir
})

$g = $form.CreateGraphics()
$k = $g.DpiX / 96
$g.Dispose()
if ($k -ne 1) { $form.Scale((New-Object Drawing.SizeF($k, $k))) }
$area = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
if ($form.Height -gt $area.Height) { $form.Height = $area.Height }
if ($form.Width -gt $area.Width) { $form.Width = $area.Width }

try { Show-Settings (Read-Settings) }
catch {
    Show-Settings (Get-DefaultSettings)
    $lblStatus.Text = "Could not read saved settings, defaults loaded: $_"
}
$form.Add_Shown({ $form.Activate(); if ($tbConsole.Text) { $tbPass.Focus() } else { $tbConsole.Focus() } })
[void]$form.ShowDialog()
