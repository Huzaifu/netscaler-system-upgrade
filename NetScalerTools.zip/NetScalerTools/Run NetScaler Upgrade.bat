@echo off
rem Opens the upgrade jobs window. Uses the PowerShell built into Windows.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0NetScalerUpgrade.ps1"
if errorlevel 1 pause
